package com.soft1851.data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataApplicationTests {

    @Test
    void contextLoads() {
    }

}
